// contentScript.js
let myPort = browser.runtime.connect({name:"port-from-cs"});

function waitForElement(elementPath, callBack){
  window.setTimeout(function(){
    if(document.getElementById(elementPath)){
      callBack(elementPath, document.getElementById(elementPath));
    }else{
      waitForElement(elementPath, callBack);
    }
  },2000)
}

function pinta(){  
    document.getElementsByClassName("selected")[0].nextSibling.nextSibling.getElementsByTagName("a")[0].click();
    waitForElement("player",function(){
        document.getElementById("player").getElementsByClassName("fullscreen")[0].click();
        document.getElementById("player").getElementsByClassName("play")[0].click();
    });
}

myPort.onMessage.addListener(function(m) {
    pinta();
    
});