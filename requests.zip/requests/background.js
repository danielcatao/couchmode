// background-script.js

let portFromCS;

function connected(p) {
  portFromCS = p;
  portFromCS.onMessage.addListener(function(m) {
    console.log(m.greeting);
  });
}

browser.runtime.onConnect.addListener(connected);

function logURL(requestDetails) {
    if(requestDetails.url == "https://player.vimeo.com/log/outro_displayed"){
        portFromCS.postMessage({greeting: "acabei mãe!"});
    }
}

browser.webRequest.onBeforeRequest.addListener(
    logURL,
    {urls: ["<all_urls>"]}
);